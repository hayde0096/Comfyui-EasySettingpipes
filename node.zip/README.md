Just a Sampler and another settings pipe for comfyui
